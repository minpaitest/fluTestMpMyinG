import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../common/config.dart';
import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../generated/l10n.dart';
import '../../models/app.dart';
import '../../models/cart/cart_model.dart';
import '../../models/product/product.dart';
import '../../models/recent_product.dart';
import '../../routes/aware.dart';
import '../../screens/detail/index.dart';
import '../common/start_rating.dart';
import 'heart_button.dart';

class ProductItemTileView extends StatelessWidget {
  final Product item;
  final EdgeInsets padding;

  ProductItemTileView({
    this.item,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: InkWell(
              onTap: () => onTapProduct(context),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(2.0),
                child: Stack(
                  children: <Widget>[
                    Container(
                      margin: const EdgeInsets.only(bottom: 15.0),
                      child: getImageFeature(
                        () => onTapProduct(context),
                      ),
                    ),
                    if ((item.onSale ?? false) && item.regularPrice.isNotEmpty)
                      Align(
                        alignment: Alignment.topLeft,
                        child: InkWell(
                          onTap: () => onTapProduct(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 8),
                            decoration: const BoxDecoration(
                                color: Colors.redAccent,
                                borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(8))),
                            child: Text(
                              '${(100 - double.parse(item.price) / double.parse(item.regularPrice.toString()) * 100).toInt()} %',
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      )
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 4),
          if (item != null)
            Expanded(
              flex: 3,
              child: _ProductDescription(item: item),
            ),
        ],
      ),
    );
  }

  Widget getImageFeature(onTapProduct) {
    return GestureDetector(
      onTap: onTapProduct,
      child: Tools.image(
        url: item.imageFeature,
        size: kSize.medium,
        isResize: true,
        // height: _height,
        fit: BoxFit.fitHeight,
      ),
    );
  }

  onTapProduct(context) {
    if (item.imageFeature == '') return;
    Provider.of<RecentModel>(context, listen: false).addRecentProduct(item);
    //Load update item detail screen for FluxBuilder
    eventBus.fire('detail');

    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (BuildContext context) => RouteAwareWidget(
          'detail',
          child: Detail(product: item),
        ),
        fullscreenDialog: kLayoutWeb,
      ),
    );
  }
}

class _ProductDescription extends StatelessWidget {
  const _ProductDescription({Key key, this.item}) : super(key: key);

  final Product item;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final addProductToCart =
        Provider.of<CartModel>(context, listen: false).addProductToCart;

    final currency = Provider.of<AppModel>(context, listen: false).currency;
    final currencyRate = Provider.of<AppModel>(context).currencyRate;

    final isTablet = Tools.isTablet(MediaQuery.of(context));

    bool isSale = (item.onSale ?? false) &&
        Tools.getPriceProductValue(item, currency, onSale: true) !=
            Tools.getPriceProductValue(item, currency, onSale: false);

    double ratingCountFontSize = isTablet ? 16.0 : 12.0;

    return Padding(
      padding: const EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const SizedBox(height: 10),
            Text(
              item.name,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 15.0,
              ),
            ),
            const SizedBox(height: 4),
            if (isSale) const SizedBox(width: 5),
            Wrap(
              children: <Widget>[
                Text(
                  item.type == 'grouped'
                      ? 'From ${Tools.getPriceProduct(item, currencyRate, currency, onSale: true)}'
                      : Tools.getPriceProduct(item, currencyRate, currency,
                          onSale: true),
                  style: Theme.of(context).textTheme.headline6.copyWith(
                        fontSize: 18,
                        color: theme.accentColor,
                      ),
                ),
                const SizedBox(width: 10),
                if (isSale)
                  Text(
                    Tools.getPriceProduct(item, currencyRate, currency,
                        onSale: false),
                    style: Theme.of(context).textTheme.headline6.copyWith(
                          fontSize: 16,
                          color: Theme.of(context).accentColor.withOpacity(0.5),
                          decoration: TextDecoration.lineThrough,
                        ),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            if (kAdvanceConfig['showStockStatus'] && !item.isEmptyProduct())
              item.backOrdered != null && item.backOrdered
                  ? Text(
                      '${S.of(context).backOrder}',
                      style: const TextStyle(
                        color: kColorBackOrder,
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                    )
                  : Text(
                      item.inStock
                          ? S.of(context).inStock
                          : S.of(context).outOfStock,
                      style: TextStyle(
                        color: item.inStock ? kColorInStock : kColorOutOfStock,
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                    ),
            const SizedBox(height: 6),
            if (kAdvanceConfig['EnableRating'])
              if (kAdvanceConfig['hideEmptyProductListRating'] == false ||
                  (item.ratingCount != null && item.ratingCount > 0))
                SmoothStarRating(
                  allowHalfRating: true,
                  starCount: 5,
                  rating: item.averageRating ?? 0.0,
                  size: 14,
                  label: Text(
                    item.ratingCount == 0 || item.ratingCount == null
                        ? ''
                        : '${item.ratingCount} ',
                    style: TextStyle(
                      fontSize: ratingCountFontSize,
                    ),
                  ),
                  spacing: 0.0,
                ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                if (!item.isEmptyProduct() &&
                    item.type != "variable" &&
                    item.inStock)
                  FlatButton(
                    color: Theme.of(context).primaryColor,
                    textColor: Colors.white,
                    child: Text(S.of(context).addToCart),
                    onPressed: () => addProductToCart(product: item),
                  ),
                const Spacer(),
                CircleAvatar(child: HeartButton(product: item, size: 18)),
                const SizedBox(width: 8),
              ],
            ),
            const SizedBox(height: 5),
          ],
        ),
      ),
    );
  }
}
