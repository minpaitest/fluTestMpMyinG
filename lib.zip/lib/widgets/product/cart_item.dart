import 'package:flutter/material.dart';
import '../../services/index.dart';
import 'package:provider/provider.dart';

import '../../common/constants.dart';
import '../../common/tools.dart';
import '../../common/config/products.dart';
import '../../models/app.dart';
import '../../models/product/product.dart';
import '../../models/product/product_variation.dart';
import 'product_variant.dart';

class ShoppingCartRow extends StatelessWidget {
  ShoppingCartRow(
      {@required this.product,
      @required this.quantity,
      this.onRemove,
      this.onChangeQuantity,
      this.variation});

  final Product product;
  final ProductVariation variation;
  final int quantity;
  final Function onChangeQuantity;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    String currency = Provider.of<AppModel>(context).currency;
    final currencyRate = Provider.of<AppModel>(context).currencyRate;

    final price = Services()
        .widget
        .getPriceItemInCart(product, variation, currencyRate, currency);
    final imageFeature = variation != null && variation.imageFeature != null
        ? variation.imageFeature
        : product.imageFeature;
    int maxQuantity = kCartDetail['maxAllowQuantity'] ?? 100;
    int totalQuantity = variation != null
        ? (variation.stockQuantity ?? maxQuantity)
        : (product.stockQuantity ?? maxQuantity);
    int limitQuantity =
        totalQuantity > maxQuantity ? maxQuantity : totalQuantity;

    ThemeData theme = Theme.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        return Column(children: [
          Row(
            key: ValueKey(product.id),
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (onRemove != null)
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed: onRemove,
                ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Container(
                              width: constraints.maxWidth * 0.25,
                              height: constraints.maxWidth * 0.3,
                              child: Tools.image(url: imageFeature)),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border.all(width: 1.0, color: kGrey200),
                                color: Theme.of(context).backgroundColor,
                                borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(2.0)),
                              ),
                              child: QuantitySelection(
                                width: 60,
                                height: 32,
                                color: Theme.of(context).accentColor,
                                limitSelectQuantity: limitQuantity,
                                value: quantity,
                                onChanged: onChangeQuantity,
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(width: 16.0),
                      Expanded(
                        child: Container(
                          height: constraints.maxWidth * 0.3,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                product.name,
                                style: TextStyle(
                                  color: theme.accentColor,
                                ),
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 7),
                              Text(
                                price,
                                style: TextStyle(
                                    color: theme.accentColor, fontSize: 14),
                              ),
                              const SizedBox(height: 10),
                              variation != null
                                  ? Services()
                                      .widget
                                      .renderVariantCartItem(variation)
                                  : Container(),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10.0),
          const Divider(color: kGrey200, height: 1),
          const SizedBox(height: 10.0),
        ]);
      },
    );
  }
}
