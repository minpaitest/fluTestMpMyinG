class BackdropConstants {
  static const double drawerWidth = 250;
}
