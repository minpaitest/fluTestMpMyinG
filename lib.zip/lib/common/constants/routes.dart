/// route list constant
class RouteList {

  // Home
  static const String home = '/home';
  static const String homeScreen = '/home-screen';
  static const String homeSearch = '/home-search';

  static const String login = '/login';
  static const String register = '/register';

}
