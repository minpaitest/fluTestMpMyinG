class MockConstants {
  static String mockDataBlog = 'lib/config/mocks/get_blog.json';
  static String mockDataCategoryByPage =
      'lib/config/mocks/get_category_by_page.json';
  static String mockDataProductByCategory =
      'lib/config/mocks/fetch_product_by_category.json';
  static String mockDataProductLayout =
      'lib/config/mocks/fetch_product_layout.json';
}
