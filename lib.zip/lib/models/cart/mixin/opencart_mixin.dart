import 'cart_mixin.dart';

mixin OpencartMixin on CartMixin {
  final Map<String, dynamic> productOptionInCart = {};
}
