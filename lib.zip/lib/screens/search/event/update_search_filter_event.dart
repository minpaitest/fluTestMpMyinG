

class UpdateSearchFilterEvent{
}